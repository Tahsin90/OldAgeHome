/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package oldagehome;

/**
 *
 * @author DELL
 */
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;



public class database {
    Connection connect = null;
    
    public int e;
    
    public void connectDatabase(){
        try{
//            Class.forName("com.mysql.jdbc.Driver");
            connect = DriverManager.getConnection("jdbc:mysql://localhost/old_age_home","root","");
            System.out.println("Successfully Connected to Mysql");

        }catch(Exception e){
            System.out.println("Not Connected..");
            e.printStackTrace();
        }
    }
    
    
    public void insertData(String userIdText,String nameText, String passwordText,String emailAddressText, String phoneText ){
        try{
            String query = "INSERT INTO user_admin(userIdText, nameText,passwordText,emailAddressText,phoneText) values(?,?,?,?,?)";
            PreparedStatement pStatement = connect.prepareStatement(query);
            pStatement.setString(1, userIdText);
            pStatement.setString(2, nameText);
            pStatement.setString(3, passwordText);
            pStatement.setString(4, emailAddressText);
            pStatement.setString(5, phoneText);
           
          
            
            
            pStatement.executeUpdate();
            
            System.out.println("Successfully Inserted..");
            
            
        }catch(Exception e){
            System.out.println("Error in inserting");
            e.printStackTrace();
        }
        
     }
    String name1,gender1, religion1,phone1,bGroup1,bithdate1,adultA1;
    
     public void insertInhabitantDataConfirm(String foodi,String regularM, String healthC,String healthI ){
        try{
            
//            ResultSet resultSet2 = null;
//            String q2="SELECT user_id FROM user WHERE email= ?";
//            PreparedStatement pStatement7 = connect.prepareStatement(q2);
//            pStatement7.setString(1, signIn.email);
//            
//            
//            
//            resultSet2=pStatement7.executeQuery();
//            
//            while (resultSet2.next()) {
//               e = resultSet2.getInt("user_id");
//                
//            }
            
            
            
            String query = "INSERT INTO inhabitants(adult_allwowance,religion,b_date,gender,name,phn_no) values(?,?,?,?,?,?)";
            
            
            //System.out.println("Re;ogopm "+religion1+" phon" +phone1+"grp"+bGroup1+" "+adultA1);    
            //System.out.println("Food"+foodi);
       
            PreparedStatement pStatement = connect.prepareStatement(query);
            pStatement.setString(1, adultA1);
            pStatement.setString(2, religion1);
             pStatement.setString(3, bithdate1);
            pStatement.setString(4, gender1);
            pStatement.setString(5,name1);
            
            pStatement.setString(6,phone1);
            
            String query2 = "INSERT INTO foods(food_issue) values(?)";
            PreparedStatement pStatement2 = connect.prepareStatement(query2);
            //pStatement2.setInt(1, e);
            pStatement2.setString(1, foodi);  
            
             //pStatement2.setString(1, "1");      
             
              String query3 = "INSERT INTO medicalrecords (medicine,health_issue,health_condition,blood_group) values(?,?,?,?)";
             
              
              PreparedStatement pStatement3 = connect.prepareStatement(query3);
              
             
             pStatement3.setString(1,regularM );
               pStatement3.setString(2, healthI);
              // pStatement3.setString(2,"1");
                pStatement3.setString(3, healthC);
              pStatement3.setString(4,bGroup1 );
           
                     
            
            pStatement.executeUpdate();
            pStatement2.executeUpdate();
              pStatement3.executeUpdate();      
            
            System.out.println("Successfully Inserted..");
            
            
        }catch(Exception e){
            System.out.println("Error in inserting");
            e.printStackTrace();
        }
        
     }
     
     
     
     public void insertRelativesData(String rNameText,String rGenderText,String rRwithIText,String relPhoneText,String rEmailText,String rOccupationText,String id){
        try{
          //  database db = new database();
              //int id=db.searchId("i_id","inhabitants");
           // incInhabitant23 view= new incInhabitant23();
           //  view.setuid(id);
           // incInhabitant3 view=new incInhabitant3();
         //view.getuid(uid12);
         
           
            String query = "INSERT INTO relatives(r_name,phn_no,email,gender,relationship,occupation,i_id) values(?,?,?,?,?,?,?)";
            PreparedStatement pStatement = connect.prepareStatement(query);
//           r_id	r_name	phn_no	email	gender	relationship	occupation	i_id
 
            pStatement.setString(1,rNameText);
            pStatement.setString(2, relPhoneText);
            pStatement.setString(3, rEmailText);
            pStatement.setString(4, rGenderText);
            pStatement.setString(5, rRwithIText);
            pStatement.setString(6, rOccupationText);
            pStatement.setString(7, id);
           
            pStatement.executeUpdate();
            
            System.out.println("Successfully Inserted..");
            
            
        }catch(Exception e){
            System.out.println("Error in inserting");
            e.printStackTrace();
        }
        
     }
     
     
     
     
     
     
     
     
     
     
     
     
     
     
     public void insertEmployeeData(String EnameText,String EgenderText,String EphoneText,String EjoiningText,String EsalaryText,String EtypeText){
        try{
            String query = "INSERT INTO employees(e_name,gender,salary,phn_no,joining_date,e_type) values(?,?,?,?,?,?)";
            PreparedStatement pStatement = connect.prepareStatement(query);
            
            pStatement.setString(1, EnameText);
            pStatement.setString(2, EgenderText);
            pStatement.setString(3, EsalaryText);
            pStatement.setString(4, EphoneText);
            pStatement.setString(5, EjoiningText);
            pStatement.setString(6, EtypeText);
           
            pStatement.executeUpdate();
            
            System.out.println("Successfully Inserted..");
            
            
        }catch(Exception e){
            System.out.println("Error in inserting");
            e.printStackTrace();
        }
        
     }
     
     
     
     
     
              
           
        
         
        int searchId(String column, String table) {
        int id = 0;
        try {

            String query = "SELECT max("+column+") as max FROM "+table;
            PreparedStatement pStatement = connect.prepareStatement(query);
          
            ResultSet a = pStatement.executeQuery();

            while (a.next()) {
                id = a.getInt("max");
                System.out.println("Id ="+id);
            }

        } catch (Exception e) {
            System.out.println("Error in Query..");
           //Component frame = null;

            e.printStackTrace();
        }

        return id;

    }
        
     
     public void getDataFromFPage(String name,String gender, String religion,String phone,String bGroup, String bithdate, String adultA){
         name1=name;
         
         gender1=gender;
        
         religion1=religion;
         phone1=phone;
         bGroup1= bGroup;
         bithdate1=bithdate;
         adultA1=adultA;
         
     }
    
    
    
    
    public ResultSet testQuery(){
            ResultSet resultSet = null;
        try{
            String query = "SELECT * FROM user_admin";
            Statement statement ;
            statement = connect.createStatement();
            resultSet = statement.executeQuery(query);
 
            
            System.out.println("Successfully Done Query..");
           
        }catch(Exception e){
            System.out.println("Error in Query..");
            e.printStackTrace();
        }           
        return resultSet;
    }

    
    
    
    
}
